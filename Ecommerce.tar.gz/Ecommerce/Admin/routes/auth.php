<?php

Route::get('/admin/login','AuthController@showLoginForm');
